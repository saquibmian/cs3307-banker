//
//  Configuration.cpp
//  Banker
//
//  Created by Saquib Mian on 2014-09-14.
//  Copyright (c) 2014 Saquib Mian. All rights reserved.
//

#include "Configuration.h"

namespace Configuration {
    
    bool isDebug = false;
    string dataDirectory = ".";
    string traceFile = "TRACE";
    
}
